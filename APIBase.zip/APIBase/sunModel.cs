﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APIBase
{
    public class sunModel
    {
        public DateTime Sunrise { get; set; }
        public DateTime Sunset { get; set; }
    }
}
