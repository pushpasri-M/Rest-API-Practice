﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APIBase
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        private async void button1_Click(object sender, EventArgs e)
        {
            sunModel sun = await SunResult.LoadCom();
            textBox1.Text = sun.Sunrise.ToLocalTime().ToShortTimeString();
            textBox2.Text = sun.Sunset.ToLocalTime().ToShortTimeString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

           button1_Click(sender, e);

        }
    }
}
